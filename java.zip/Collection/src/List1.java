import java.util.Iterator;
import java.util.ArrayList;
public class List1 {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<>();
		al.add("Wipro");
		al.add("Wipro tech");
		al.add("Wipro ltd");
		al.add("Wipro company");
		al.add("Wipro chennai");
		//System.out.println(al);
		Iterator<String> it=al.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
				
	}

}
