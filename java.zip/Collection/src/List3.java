import java.util.*;
public class List3 {
	public static void main(String[] args) {
	
	Vector v= new Vector();
	v.addElement(10);
	v.addElement(20);
	v.addElement(30);
	v.addElement(40);
	
	Enumeration e=Collections.enumeration(v);
	System.out.println("Enumeration list:");
	while(e.hasMoreElements())
	{
		System.out.println(e.hasMoreElements());
	}
	
	}
}