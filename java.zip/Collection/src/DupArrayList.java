import java.util.ArrayList;
class DupArrayList<E> extends ArrayList<E> {
	public boolean add(E ele)
	{
		if(ele instanceOf Integer || ele instanceOf Float || ele instanceOf Double)
		
	}
}
