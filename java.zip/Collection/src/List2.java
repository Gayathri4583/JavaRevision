import java.util.ArrayList;
import java.awt.List;
class MyArrayList<E> extends ArrayList<E>{
	@Override
	public boolean add(E e) {
		if(e instanceof Integer || e instanceof Float || e instanceof Double)
		{
			super.add(e);
			return true;
		}
		else
			throw new ClassCastException("Only Integer, Float, and Double are supported."); 
		}
	}
public class List2 
{

	public static void main(String[] args) 
	{ 
		MyArrayList<Object> l=new MyArrayList<>();
	
		try 
		{
		l.add(13);
		l.add(1.2);
		l.add(13.34D);
		
		}
	
		catch(Exception e)
		{
		e.printStackTrace();
		}
		System.out.println(l);
	}

}