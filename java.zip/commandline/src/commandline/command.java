import java.util.*;
public class commandline() 
{
	public class void main(String args[]) 
	{
		for(i=0;i<args.length;i++)
		System.out.println(args[i])
	}
}
