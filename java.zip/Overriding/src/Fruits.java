
public class Fruits {

	
		String name;
		String taste;
		String size;
	
	void eat() {
		System.out.println("This fruit is edible to eat");
	}

}