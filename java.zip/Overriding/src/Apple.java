class Apple extends Fruits{

	Apple() {
		name="Apple";
		taste="Sweet";
		size="medium";
	}
	//@override
	void eat() {
		System.out.println("This" +name+ "is edible to eat");
	}

}
