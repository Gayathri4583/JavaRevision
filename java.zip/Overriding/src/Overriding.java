
public class Overriding {

	public static void main(String[] args) {
		Fruits fruit=new Fruits();
		Apple apple=new Apple();
		Orange orange=new Orange();
		fruit.eat();
		apple.eat();
		orange.eat();

	}

}
