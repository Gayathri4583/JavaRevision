
class Orange extends Fruits{

	Orange() {
		name="Orange";
		taste="Sweet-tert";
		size="medium";
	}
	
	void eat() {
		System.out.println("This "+name+" is edible to eat");
	}

}
