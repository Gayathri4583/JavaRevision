
public class Encapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Author author=new Author("Ravindra Singh","ravindra.singh@gmail.com",'M');
		Book obj= new Book("Master in Java", author, 199.0, 500);
		System.out.println("book name: "+obj.getName()+" price: "+obj.getPrice()+" Quantity: "+obj.getQtyInStock()+" Author name:");
		System.out.println("name: "+obj.getAuthor().name);		

	}

}
