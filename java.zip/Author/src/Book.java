
public class Book {

		private String name;
		private Author author;
		private double price;
		private int qtyInStock;

		public Book(String name,Author author,double price,int qtyInStock)
		{
		this.name = name;
		this.author = author;
		this.price = price;
		this.qtyInStock = qtyInStock;
		}
		public String getName()
		{
		return name;
		}
		public void setName(String newName) {
		    this.name = newName;
		}
		public Author getAuthor()
		{
		return author;
		}
		public void setAuthor(Author newAuthor) {
		    this.author = newAuthor;
		}
		public double getPrice()
		{
		return price;
		}
		public void setPrice(double newPrice) {
		    this.price = newPrice;
		}
		public int getQtyInStock()
		{
		return qtyInStock;
		}
		
		
		
		public void setQtyInStock(int newQtyInStock) {
		    this.qtyInStock = newQtyInStock;
		}
	}


