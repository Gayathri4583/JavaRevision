import java.util.*;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class FileHandling1 {

	public static void main(String[] args)throws IOException  {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the file name:");
		String filename= sc.nextLine();
		
		System.out.println("Enter the char to count:");
		char letter=sc.nextLine().charAt(0);
		
		
		File file=new File("C:\\\\Users\\\\SANJEEVI\\\\Desktop\\\\TRAINING\\\\input.txt");
		int charCount= 0;
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		 
		int ch;
		do {
			ch=br.read();
			if(ch>=65 && ch<=90) ch+=32;
			if(letter>=65 && letter<=90) letter+=32;
			if (ch==letter)
				charCount++;
			}
		while (ch!=-1);
		System.out.println("File '" + filename + "' has " +
				charCount + " instances of letter '" + letter + "'.");
		
		br.close();
		
		
	}
}
