import java.io.File;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
public class FileCreation {

	public static void main(String[] args) {
		File file=new File("C:\\Users\\SANJEEVI\\Desktop\\TRAINING\\input1.txt");
		FileWriter fw;
		FileReader fr;
		int lineCount=0; 
		int sentenceCount =0;
		int wordCount=0;
		try 
		{
			fw=new FileWriter(file);
		//fw=new FileWriter(file,true);//append
		BufferedWriter bw=new BufferedWriter(fw);
		fr=new FileReader(file);
		BufferedReader br=new BufferedReader(fr);
		bw.write("Java is a programming language.I like java.");
		bw.flush();
		bw.close();
		
		String line=br.readLine();
		
		while(line!=null)
		{
			
		String[] s=line.split(" ");
		lineCount++;
		 
		
		String[] sentence=line.split("[.]");
		sentenceCount+=sentence.length();
		line=br.readLine();
		//wordCount+= word.length();
		
		
		
		
		}
		System.out.println("No of lines:"+lineCount);
		System.out.println("No of sentence:"+SentenceCount);
		}
		
		
		catch(IOException e){
			e.printStackTrace();			
		}
	}
}
  