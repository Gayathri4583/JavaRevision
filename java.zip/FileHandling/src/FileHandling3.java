
public class FileHandling3 {

	public static void main(String[] args) {
		

	}

}
