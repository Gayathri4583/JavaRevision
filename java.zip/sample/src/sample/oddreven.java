package sample;
import java.util.*;
public class oddreven {

	public static void main(String[] args) 
	{
		int k=3;
		if(k%2==0)
		{
			System.out.println("even");
		}
		else {
			System.out.println("odd");
		}

	}

}
