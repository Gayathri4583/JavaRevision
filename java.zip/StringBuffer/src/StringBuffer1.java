import java.util.*;
public class StringBuffer1 {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the word to check...");
		String input=sc.nextLine();
		
		StringBuffer s1=new StringBuffer(input);
		StringBuffer s2=new StringBuffer(s1);
		
		s1.reverse();
		
		System.out.println("Reversed word "+s1);
		
		if(String.valueOf(s1).compareTo(String.valueOf(s2))==0)
			System.out.println(s2+" Palindrome word");
		else
			System.out.println(s2+" It isn't Palindrome word");

	}

}
