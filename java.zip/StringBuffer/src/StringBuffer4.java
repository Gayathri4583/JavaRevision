import java.util.*;
public class StringBuffer4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string");
		String input=sc.nextLine();
		System.out.println("String:"+input);
		int n=input.length();
		if(n%2==0)
			System.out.println(input.substring(0,n/2));
		else
			System.out.println("null");
	}

}
