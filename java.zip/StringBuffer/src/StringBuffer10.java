import java.util.*;
public class StringBuffer10 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter the string: ");
		String str = scan.nextLine();
		
		System.out.print("Enter the number: ");
		int n = scan.nextInt();
		
		String repeatStr= str.substring(str.length()-n);
		String output="";
		
		for(int i=0;i<n;i++)
			output+=repeatStr;
		
		System.out.println(output);
	}

}
