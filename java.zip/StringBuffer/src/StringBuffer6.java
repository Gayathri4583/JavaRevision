import java.util.Scanner;

public class StringBuffer6 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st string");
		String input1=sc.nextLine();
		System.out.println("Enter 2rd string");
		String input2=sc.nextLine();
		int m=input1.length();
		int n=input2.length();
		if(m<n)
			System.out.println(input1+ input2 +input1);
		else
			System.out.println(input2 + input1 +input2);
	}

}
