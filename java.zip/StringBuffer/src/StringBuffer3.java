import java.util.*;
class StringBuffer3 {

	public static void main(String[] args) {

		Scanner str=new Scanner(System.in);
		
		System.out.println("Enter the string:");
		String input =str.nextLine();
		System.out.println(input);
		
		int n=input.length();
		
		String slice=input.substring(0,2);
		String output="";
		
		for (int i=0;i<n;i++) 
		{
			output+=slice;
		}
		
		System.out.println(output);

	}

}
