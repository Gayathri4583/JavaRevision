import java.util.*;

public class StringBuffer8 {

	public static void main(String[] args) {
		 {
		        String str = "ab*bd";
		        int pos = str.indexOf("*");
		        StringBuffer sbr = new StringBuffer(str);
		        sbr.delete(pos -1, pos +2);
		        System.out.println(sbr);
		    }
		}

}
