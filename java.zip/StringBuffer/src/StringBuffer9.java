
public class StringBuffer9 {

	public static void main(String[] args) {
		String str1 = "Hello";
        String str2 = "World";
        StringBuffer str = new StringBuffer();

        for(int i = 0; i < str1.length() || i < str2.length(); i++){

            if (i < str1.length())
                str.append(str1.charAt(i));

            if (i < str2.length())
                str.append(str2.charAt(i));
        }

        System.out.println(str);

	}

}
