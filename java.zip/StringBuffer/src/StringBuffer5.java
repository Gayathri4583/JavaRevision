import java.util.Scanner;

public class StringBuffer5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string");
		String input=sc.nextLine();
		System.out.println("String:"+input.substring(1,input.length()-1));
		}
}