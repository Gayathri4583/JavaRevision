
public class Employee extends Person{
	String name;
	double annualSalary;
	int yearOfStart;
	String nationalInsuranceNo;
	
	Employee(String name,double annualSalary,int yearOfStart,String nationalInsuranceNo) 
	{
		super(name);
		this.annualSalary = annualSalary;
		this.yearOfStart = yearOfStart;
		this.nationalInsuranceNo = nationalInsuranceNo;
	}
	void setannualSalary(double salary){
        this.annualSalary = annualSalary;
    }
	double getAnnualSalary() {
		return annualSalary;
	}
	void setyearOfStart(int yearOfStart){
        this.yearOfStart = yearOfStart;
    }
	int getYearOfStart() {
		return yearOfStart;
	}
	 void setNationalInsuranceNo(String NationalInsuranceNo){
	        this.NationalInsuranceNo = NationalInsuranceNo;
	    }
	String getNationalInsuranceNo() {
		return nationalInsuranceNo;
	}
}
