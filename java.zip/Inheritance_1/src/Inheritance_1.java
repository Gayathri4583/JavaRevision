
public class Inheritance_1 {

	public static void main(String[] args) {
		//Person p1 = new Person("Brandon");
		Employee emp = new Employee("Saini",500000, 20120, "1234567");
		
		System.out.println("Details of Employee:");
		System.out.println("Name: " + emp.getName());
		System.out.println("Year Of Starting: " + emp.getYearOfStart());
		System.out.println("Annual Salary: " + emp.getAnnualSalary());
		System.out.println("Insurance Number: " + emp.getNationalInsuranceNo());
	}

}
