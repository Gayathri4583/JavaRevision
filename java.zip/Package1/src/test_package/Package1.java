package test_package;

public class Package1 {

	public static void main(String[] args) {
		Foundation f=new Foundation();
		//f.var1=1;//	The field Foundation.var1 is not visible
		f.var2=23;
		f.var3=90;
		f.var4=50;
		//System.out.println(f.var1);
		System.out.println(f.var2);
		System.out.println(f.var3);
		System.out.println(f.var4);
	}

}
