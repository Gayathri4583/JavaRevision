package test_package;
	public class Foundation {
		private int var1;
		int var2;
		protected int var3;
		public int var4;

	}


