package snippet;

public class Snippet {
	Please choose another workspace as 'C:/Users/SANJEEVI/Desktop/New folder' is currently in use.
}

