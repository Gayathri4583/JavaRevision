package music.string;
import music.Playable;
public class Veena implements Playable {

	public void play() {
		System.out.println("Playing veena");
	}

}
