package com.wipro.automobile.ship;

public class Package2 {

	public static void main(String[] args) {
		Compartment c= new Compartment(1000.10,550.5,450.45);
		System.out.println(c);

	}

}
