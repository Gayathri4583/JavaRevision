import java.util.*;
public class ExceptionHandling1 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number of elements in an array:");
	int len=sc.nextInt();
	int[] arr=new int[len];
	System.out.println("Enter the element for an array:");
	try {
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the index of the array to access:");
		int ind=sc.nextInt();
		System.out.println("The array element at the index:"+arr[ind]);
		System.out.println("The array found successfully!");
	}
	catch(ArrayIndexOutOfBoundsException e){
		System.out.println(e);
	}
	catch(InputMismatchException e){
		System.out.println("NumberFormatException");
	}
}
}
