import java.util.*;
import java.lang.Exception.*;
class InvalidCountryException extends Exception{
	public InvalidCountryException() {
		System.out.println("InvalidCountryException occured");
	}
}
public class UserRegistration {
	public void registerUser(String username,String userCountry) throws InvalidCountryException
	{
		if(!userCountry.equals("India"))
			throw new InvalidCountryException();
		else
			System.out.println("User registered successfully!");
	}

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		
		String name="";
		System.out.println("User Name:");
		name=sc.nextLine();

		String countryName="";
		System.out.println("Name of country:");
		countryName=sc.nextLine();
		
		UserRegistration reg = new UserRegistration();
		
		try {
			reg.registerUser(name, countryName);
		}
		catch(InvalidCountryException e){
			System.out.println(e.getMessage());
		}
	}

}