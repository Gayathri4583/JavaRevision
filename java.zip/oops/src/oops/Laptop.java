package oops;

public class Laptop {

	public Laptop()//this is non paramaterized constructor
	{
		System.out.println("Constructor of lap class");
	}
	void laptopMethod() {
		System.out.println("full battery!!");
	}

}
