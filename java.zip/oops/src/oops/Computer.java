package oops;

public class Computer {
	
	public static void main(String[] args) {
		Laptop obj = new Laptop();
		obj.laptopMethod();
	}

}
