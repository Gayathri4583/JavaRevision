package com.automobile.fourwheeler;
import com.automobile.Vehicle;
public class Logan extends Vehicle {
	private String modelName;
	private String regNum;
	private String ownerName;
	private int speed;
	public Logan(String modelName,String regNum,String ownerName,int speed) {
		this.modelName=modelName;
		this.regNum = regNum;
		this.ownerName = ownerName;
		this.speed=speed;
	}
	public String getModelName() {
		return modelName;
	}
	public String getRegistrationNumber() {
		return regNum;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public int getSpeed() {
		return speed;
	}
	public void gps() {
		System.out.println("Controlling GPS device");
	}

}
