package com.automobile;

import com.automobile.fourwheeler.Ford;
import com.automobile.fourwheeler.Logan;

public class TestFourwheeler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logan logan= new Logan("Logan 1.4 GLE", "TN01 G 8055", "Gayathri", 148);
		System.out.println(logan.getModelName());
		System.out.println(logan.getRegistrationNumber());
		System.out.println(logan.getOwnerName());
		System.out.println(logan.getSpeed()+" kmph");
		logan.gps();
		
		System.out.println();
		
		Ford ford= new Ford("Ford Endeavour", "TN01 G 1000", "Dharani", 160);
		System.out.println(ford.getModelName());
		System.out.println(ford.getRegistrationNumber());
		System.out.println(ford.getOwnerName());
		System.out.println(ford.getSpeed()+" kmph");
		ford.tempControl();
	}

}
