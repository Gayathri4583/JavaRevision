package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Honda extends Vehicle{

	private String modelName;
	private String regNum;
	private String ownerName;
	private int speed;
	public Honda(String modelName,String regNum,String ownerName,int speed) {
		this.modelName=modelName;
		this.regNum = regNum;
		this.ownerName = ownerName;
		this.speed=speed;
	}
	public String getModelName() {
		return modelName;
	}
	public String getRegistrationNumber() {
		return regNum;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public int getSpeed() {
		return speed;
	}
	public void cdPlayer() {
		System.out.println("Accessing the CD player");
	}
}
