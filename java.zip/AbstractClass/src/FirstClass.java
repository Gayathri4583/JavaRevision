import java.util.*;
class FirstClass extends Compartment
{	
	//@override
	public String notice()
	{
		return "You are in first class compartment.";
	}

}
