class General extends Compartment{
	public String notice()
	{
		return "You are in general class compartment.";
	}

}
