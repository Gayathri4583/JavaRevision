class Luggage extends Compartment{
	public String notice()
	{
		return "You are in luggage class compartment.";
	}
}