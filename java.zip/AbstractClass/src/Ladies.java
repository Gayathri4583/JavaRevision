class Ladies extends Compartment {
	public String notice()
	{
		return "You are in ladies compartment.";
	}
}