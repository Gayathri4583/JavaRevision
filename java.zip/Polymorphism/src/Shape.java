
class Shape {
	
		void draw() {
			System.out.println("Drawing shape");
		}
		void erase() {
			System.out.println("Erasing shape");
		}
	

}
