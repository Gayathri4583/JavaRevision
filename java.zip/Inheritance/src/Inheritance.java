
public class Inheritance {

	public static void main(String[] args) {
				Animal animal=new Animal();
				animal.eat();
				animal.sleep();
				Birds bird=new Birds();
				bird.fly();
				bird.eat();
				bird.sleep();
			}
		}
