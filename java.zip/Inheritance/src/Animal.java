
public class Animal {

	public Animal() {

		void eat() {
			System.out.println("Animal is eating");
		}
		void sleep() {
			System.out.println("Animal is sleeping");
		}
	}

}
