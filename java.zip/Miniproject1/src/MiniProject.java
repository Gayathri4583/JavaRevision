import java.util.*;
public class MiniProject {

	public static void main(String[] args) {
	       Scanner sc = new Scanner(System.in);
	        String[][] a=new String[7][8];
	        int k=0;
	        for(int i=0;i<7;i++)
	        {
	            for(int j=0;j<8;j++)
	            {
	                a[i][j]=sc.next();
	            }
	        }
	        int b=0,h=0,it=0,da=0,salary=0,c=0;
	        String en="",ena="",d="",department="";
	        //System.out.println("the given array is:");
	        for(int i=0;i<7;i++)
	        {
	            for(int j=0;j<8;j++)
	            {
	                //System.out.print(a[i][j]+"\t");
	            }
	            //System.out.println();
	        }
	        //System.out.println("Enter the employee number: ");
	        String n = sc.next();
	        for(int i=0;i<7;i++)
	        {
	            for(int j=0;j<8;j++)
	            {
	                if((a[i][j]).equalsIgnoreCase(n))
	                {
	                    c++;
	                    en+=a[i][0];
	                    ena+=a[i][1];
	                    department+=a[i][4];
	                    b=Integer.parseInt(a[i][5]);
	                    h=Integer.parseInt(a[i][6]);
	                    it=Integer.parseInt(a[i][7]);
	                    switch(a[i][3])
	                    {
	                        case "e":
	                            da=20000;
	                            d+="Engineer";
	                            break;
	                        case "c":
	                            da=32000;
	                            d+="Consultant";
	                            break;
	                        case "k":
	                            da=12000;
	                            d+="Clerk";
	                            break;
	                        case "r":
	                            da=15000;
	                            d+="Receptionist";
	                            break;
	                        case "m":
	                            da=40000;
	                            d+="Manager";
	                            break;
	                    }
	                }
	            }
	        }
	        if(c>0){
	        salary=b+h+da-it;
	        System.out.println("Emp no.   "+"Emp Name "+"Department   "+"Desigination   "+"Salary   ");
	        System.out.println(en+"\t   "+ena+"\t"+department+"\t        "+d+"\t    "+salary);
	        }
	        else
	        {
	            System.out.print("There is no employee with empid:"+n);
	        }

	}

}
