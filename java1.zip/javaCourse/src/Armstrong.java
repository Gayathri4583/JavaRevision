
public class Armstrong {

	public static void main(String[] args) {
		int mynu=153;
		//System.out.println(r);
		int check=mynu,result=0,rem=0;
		while(check>0) {
			rem=check%10;
			result+=(rem*rem*rem);
			check/=10;
		}
		if(result==mynu)
			System.out.println(mynu+" is Armstrong number");
		else
			System.out.println(mynu+" is not Armstrong number");
	}
	
}
