package demopackage;

public class Bank {
	private double AccNo;
	private double Balance;
	public void enquiry(double AccNo,double Balance ) {
		this.AccNo=AccNo;
		this.Balance=Balance;
		System.out.println("A_no:"+AccNo);
		System.out.println("Initial Bal"+Balance);
	}
	public void deposite(double amt ) {
		if(amt>0) {
			Balance+=amt;
			System.out.println("Deposited"+" Balance is"+Balance);
		}
		else
			System.out.println("Invalid input");
			
	}
	public void withdraw(double amt ) {
		if(amt>0) {
			if(amt<=Balance) {
			Balance-=amt;
			System.out.println("Balance is "+Balance);}
		
		else
			System.out.println("Not sufficient balance");}
	}
	
	public static void main(String[] args) {
		Bank b=new Bank();
		b.enquiry(92386197269d, 100);
		b.deposite(0);
		b.withdraw(2000);
	}

}
