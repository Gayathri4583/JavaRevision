package demopackage;

public class democlass  {
	public static void multiply(int arg1,int arg2) {
		int results=arg1*arg2;
		System.out.println("*:"+results);
		
	}
	
	public static int div(int a,int b) {
		int result1=a/b;
		return result1;
	}
}


//public --can access from anywhere and from another package
//private-same class only
//default -- any class not from another package
//protected--- same package

/* keywords
static- saves the storage no need to create object
final - cant use again
super- super.gender ... super.print();  access the parent class's method or variable etc 
this- access the instance variables this.gender=gender     *
/*
 toSt
 */
 