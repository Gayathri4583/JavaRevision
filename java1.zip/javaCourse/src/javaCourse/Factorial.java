package javaCourse;

import java.util.Scanner;

public class Factorial {
	public static int fact(int n) {
		int result;
		if (n<0)
			return 0;
		else if(n==1)
			return 1;
		else
			return n*fact(n-1);
			
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("n:");
		int n=sc.nextInt();
		
		System.out.println(fact(n));

	}

}
