package javaCourse;

public class ArraySum {

	public static void main(String[] args) {
		int[] a= {45,78,4,0,4,5};
		int sum=a[0];
		int max=a[0];
		int min=a[0];
		for(int i=0;i<a.length;i++) {//sum
			sum+=a[i];
		}
		System.out.println("Sum:"+sum);
		for(int j=1;j<a.length;j++) {
			
			if(a[j]>max) {
				max=a[j];
			}
			else if(a[j]<min) {
				min=a[j];
			}
		}
		int avg;
		avg=sum/a.length;
		System.out.println("Avg:"+avg);
		System.out.println("Max:"+max+" "+"Min:"+min);
//	reverse string
		String s="irhtayag",reverse="";
		char ch;
		for(int x=0;x<s.length();x++) {
			ch=s.charAt(x);
			reverse=ch+reverse;
		}
		System.out.println("Reversed string:"+reverse);
		
		
		   int[] a1={12,1,0,11,-23};
	        int t=0;
	        
	        for(int i=0;i<a1.length;i++){
	        for(int j=i+1;j<a1.length;j++){
	            if(a1[i]>a1[j])
	            {
	            t=a1[i];
	            a1[i]=a1[j];
	            a1[j]=t;
	        }
	            }
	       
	        System.out.println(a1[i]);
	        

	}

}}
