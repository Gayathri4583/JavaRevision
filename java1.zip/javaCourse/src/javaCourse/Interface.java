package javaCourse;

public class Interface implements InMain,InBranch {
	
		public void sales1() {
			System.out.println("Good Sales in sales1");
		}
		public void sales2() {
			System.out.println("Better Sales in sales2");
		}
	
	public static void main(String[] args) {
		Shop s=new Shop();
		s.sales1();
		s.sales2();
	}

}

interface InMain{
	abstract void sales1();
	abstract void sales2();
}
interface InBranch{
	abstract void sales1();
	abstract void sales2();
}