package javaCourse;
class CakeShop{
	public void run() {
		System.out.println("Mixing ingredients "+Thread.currentThread().getId());
		System.out.println("Baking "+Thread.currentThread().getId());
		System.out.println("Making designs "+Thread.currentThread().getId());
		System.out.println("Ready for delivery "+Thread.currentThread().getId());
	}
}
public class Multithreading {

	public static void main(String[] args) {
		CakeShop cake=new CakeShop();
		int size=4;
		for(int i=1;i<size;i++) {
			cake.run();
		}
	}

}
