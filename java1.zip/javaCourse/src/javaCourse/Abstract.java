package javaCourse;
abstract class Shapes{//methods inside abstract class must use in another class when abstract class extends
abstract void perimeter();
	void area() {
		System.out.println("Hi Im shapes!!!");
	}
}
class Rectangle extends Shapes{
	int l=12;
		int b=10;
	void area() {
	
	int area=l*b;
	System.out.println("Rec A:"+area);
	}
	void perimeter() {
	int perimeter=2*l*b;
	System.out.println("Rec P:"+perimeter);
	}
}

class Sq extends Shapes{
	int a=10;
	void area() {
		int area=a*a;
		System.out.println("Square A:"+area);
	}
	void perimeter() {
		int perimeter=4*a;
		System.out.println("Square P: "+perimeter);
	}
}

public class Abstract {

	public static void main(String[] args) {
		Rectangle r=new Rectangle();
		r.area();
		r.perimeter();
		Sq s=new Sq();
		s.area();
		s.perimeter();

	}

}
