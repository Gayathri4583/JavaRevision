package javaCourse;

public class TypesInheritance {

	public static void main(String[] args) {
		Students result=new Students();
		result.van(20);
		System.out.println(result.gender);
		System.out.println(result.stu_no);
		
		Science s=new Science();
		s.Science("Bring Hibiscus");
		
		Son s1=new Son();
		s1.song();
		s1.work();
		Daughter d=new Daughter();
		d.work();
		d.display("Isqq all");
		

	}}
	class School{// father son
		int stu_no=100;
		void van(int n) {
			System.out.println(n);
		}
	}
	class Students extends School{
		String gender="female";
		void Science(String rules) {
			System.out.println("A1 group");
			System.out.println(rules);
		}
	}
	class Science extends Students{// multi level grandma mom daughter
		//method overriding program
	}

	class Father{//heiararchical 
		
		void work() {
			System.out.println("I can work");
		}
	}
	class Son extends Father{
		char gender='M';
		void song() {
			System.out.println("I can sing");
		}
	}
	class Daughter extends Father{
		void display(String msg) {
			System.out.println(msg);
		}
	}
	
	
	
	
	
	