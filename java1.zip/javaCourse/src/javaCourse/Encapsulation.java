package javaCourse;
//combining functions or methods under one class or data
public class Encapsulation {
	public int get(int rolno) {
		return rolno;
	}
	public void display(String st) {
		String name=st;
		System.out.println(name);
	}

	public static void main(String[] args) {
		Encapsulation cap=new Encapsulation();
		System.out.println(cap.get(23));
		cap.display("ashiwini");

	}

}
//Abstraction - Hiding unnecessary details to user like giving private access specifiers