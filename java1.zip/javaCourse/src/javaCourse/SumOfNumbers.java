package javaCourse;

public class SumOfNumbers {

	public static void main(String[] args) {
		int x,y,sum;
		x=10;
		y=10;
		sum=x+y;
		System.out.println("SUM:"+sum);
		if(x%2==0)
			System.out.println(x+" is even");
		else 
			System.out.println(x+" is odd");
	
//	toString
//	toBinaryString
//	valueOf or ParseInt
//	toHexString
//	toOctalString
		String s=Integer.toBinaryString(12);
		System.out.println(s);
		String a=Integer.toHexString(12);
		System.out.println(a);
		String b=Integer.toOctalString(12);
		System.out.println(b);
		int cv=Integer.parseInt("d");
		System.out.println(cv);
		
	}

}
