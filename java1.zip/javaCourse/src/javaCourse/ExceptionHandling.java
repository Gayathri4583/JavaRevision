package javaCourse;
class Userdefined extends Exception{ // must extends Exception
	String s;
	Userdefined(String str) {
		this.s=str;// super(str);
	}
}
public class ExceptionHandling {
	
	static void exceptionCheck(int age) throws Userdefined {
		if(age<18)
			throw new Userdefined("Age invalid");
	}
	public static void main(String[] args) {
		int a=19,b=0;
		int c=a/b;
		try {
			
			throw new ArithmeticException("Invalid");
			//System.out.println(c);
		}
		catch(ArithmeticException E) {
			System.out.println(E.getMessage());
			//System.out.println("Divisor can't be 0");
		}
		finally {
			System.out.println("I will print even if failed and succeed");
		}
		
		
	}

}
