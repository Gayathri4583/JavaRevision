package javaCourse; //class and objects

public class ClassDemo {
	long rollno;
	String name;
	
	public void display() {
		System.out.println("Roll NO:"+rollno);
		System.out.println("Name:"+name);
	}
	
	public void values(String s,int n) {
		name= s;
		rollno= n;
	}
	ClassDemo(){
		System.out.println("Used for default outputs!!");
	}
	public static void main(String[] args) {
		//creating constructor --> it has same as class name
		ClassDemo obj=new ClassDemo();
		obj.rollno=721718104018L;
		obj.name="Gayathri V";
		obj.display();
		
		ClassDemo obj1=new ClassDemo();
		obj1.values("Sanjeevi V", 2413);
		obj1.display();
		
		//constructors - spl type of function or method , called implicitly {itself},same as class name dont wanna call explicitly
		//constructors vs method == method has void- return type , different name ,have to call by us
		ClassDemo sc=new ClassDemo();
		
	}
}
