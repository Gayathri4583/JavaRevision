package javaCourse;

public class Oop {

	public static void main(String[] args) {
		// polymorphism == method overloading same method name but has some signature activity like different parameters
		Oop obj=new Oop();
		obj.displayMin();
		obj.displayMin(1);
		obj.displayMin(1,2);
	}
	
		public void displayMin() {
			System.out.println("Display without arguments");
		}
		public void displayMin(int a) {
			System.out.println("i have one arguments..."+a);
		}
		public void displayMin(int a,int b) {
			System.out.println("many arguments..."+a+b);
		}
	}

