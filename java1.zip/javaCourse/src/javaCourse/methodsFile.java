package javaCourse;

public class methodsFile {
	protected static void add(int arg1,int arg2) {
		int results=arg1+arg2;
		System.out.println("add:"+results);
		
	}
	
	public static int sub(int a,int b) {
		int result1=a-b;
		return result1;
	}
}
