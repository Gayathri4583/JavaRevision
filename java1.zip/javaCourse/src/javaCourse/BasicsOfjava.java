
package javaCourse;

import demopackage.democlass;

public class BasicsOfjava {

	public static void main(String[] args) {
		// Variables and Datatypes
		int var1=10;
		short var2=13941;
		byte var3='w';
		long var4=2489735897L;
		float var5=1309.3509f;
		double var6=10.23d;
		boolean var7=true;
		String var8="Gayathri";
		
		//arrays
		String[] arr=new String[] {"my","name","is","Gayathri"};
//		System.out.println(arr[0]);
//		System.out.println();
		
		//methods
		methodsFile.add(23, 45);
		democlass.multiply(12,656);
		
		int methodVar= methodsFile.sub(23, 10);
		System.out.println("Subtraction:"+methodVar);
		
		//operators + - * / % are arithematic
//		-- ++ decrement and increment
//		> < <= >= == != relational 

		
		int integer=12,i=45;
		integer++;
		System.out.println("result:"+integer);
		++i;
		//System.out.println(++i);
		System.out.println(i);
		
//		--a == telling that decrease at the time of using variable a pre decrement
//		a-- == decrease when the line running and when a called again show the decreased values
// a=5 sout(--a); o/p:4 
/*
 a=6;
 a++;
 sout(a);
 **/	

//		and or not logical && ||  ! boolean outputs
		
		boolean aa=true;
		boolean bb=false;
		
		System.out.println(aa || bb);
		
		int no=5;
		int sum=0;
		int j=6;
		/*while(j<=no) { //runs until the condition fails
			sum+=j;
			j++;
		}
		System.out.println("Sum:"+sum); */
		
		do {  //do==while atleast run min1 time even if false logically
			sum+=j;
			j++;
		}
		while(j<=no);
			System.out.println("Sum:"+sum);
	}
	
	
	
	
	/* static class Demo{
		void add() {
			methodsFile.add(10,12);
		} 
	
	}*/
}


