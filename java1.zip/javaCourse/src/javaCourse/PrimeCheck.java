package javaCourse;

import java.util.Scanner;

public class PrimeCheck {
	public static void prime(int max_num) {
		
		for(int i=2;i<=max_num;i++) {
			int count=0;
			for(int j=1;j<=max_num;j++ ) {
				if(i%j==0) {
					count++;
				}
			}
			if(count==2)
				System.out.println(i+" ");
		}
	}

	public static void main(String[] args) {
		PrimeCheck.prime(25); 
		
		//break and continue are jump statements
		int num=10;
		for(int a=1;a<=num;a++) {
			if(a==5) {
				continue; // left the given condition ...didnt execute next line directly goes to iteration
			} System.out.println(a);
		}
		
		int[][] mat=new int[3][4];
		mat[2][2]=25;
		for(int x=0;x<3;x++) {
		 for(int y=0;y<3;y++) {
		System.out.println(mat[x][y]);
		 }
		}
	/*	short i;
		Scanner sc=new Scanner(System.in);
		//Scanner obj1=new Scanner(System.in);
		System.out.println("number:");
		int num=sc.nextShort();

		if(num%2==0)
			System.out.println(num+" is even");
		else
			System.out.println(num+ " is odd");
		for(i=0;i<=5;i++) {
			System.out.println(i);
		} */
		
		/*
		int i,num_to_check;
		boolean flag=true;
	
		Scanner obj1=new Scanner(System.in);
		System.out.println("number:");
		num_to_check=obj1.nextInt();
		
//		1
		
		 
			for(i=2;i<=num_to_check/2;i++) {
				if((num_to_check%i)==0)
				flag=false;
				break;
		}
		if(!flag)
			System.out.println(num_to_check+" is not prime number");
		else
			System.out.println(num_to_check+" is prime number"); */
		
		
	}

}



// while loop--> run until the condition become false
