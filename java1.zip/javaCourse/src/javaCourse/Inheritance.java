package javaCourse;

class Inheritance {
// method overloading 
	public static void main(String[] args) {		
		Mine ob=new Mine();
		ob.mixed();
		System.out.println(ob.myFeeling);
		ob.happy();
		
		Employee emp=new Employee();
		System.out.println(emp.salary);
		emp.Gm(50000);
		
		emp.Manager(100000);
		System.out.println();
		Company.Gm(10000);
	}}
class Family{
	public void happy() {
		System.out.println("Happy methods");
	}
	public void sad() {
		System.out.println("Sad methods");
	}
}
class Mine extends Family{
	public void mixed() {
		int a=0;
		System.out.println("Mixed methods..."+ a);
	}
	
	boolean myFeeling= true;
}
// method overriding -- prints the values which is given in sub-classes

class Company{
	int salary=10000;
	public static void Gm(int salary){
	System.out.println(salary);	
	}
	}

class Employee extends Company{
	int salary=12000;
	public void Manager(int salary){
	salary=100000;	
	}
	}
















