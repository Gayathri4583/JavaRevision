package javaCourse;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		double var1,var2,results;
		char operator;
		Scanner obj1=new Scanner(System.in);
		System.out.println("Enter operators:+,-,*,/");
		operator=obj1.next().charAt(0);
		System.out.println("Enter firstnum:");
		var1=obj1.nextInt();
		System.out.println("Enter secondnum:");
		var2=obj1.nextInt();
		
		switch(operator)
		{
		case '+':
			results=var1+var2;
			System.out.println("SUM:"+results);
			break;
		
		case '-':
			results=var1-var2;
			System.out.println("Sub:"+results);
			break;
		
		case '*':
			results=var1+var2;
			System.out.println("Multiply of"+" "+var1+" "+var2+" "+"is"+" "+results);
			break;
		
		case '/':
			results=var1/var2;
			System.out.println("Divide of:"+results);
			break;
		
		default:
			System.out.print("Wrong operator!!!");
			break;
		
		}
		//obj1.close();

	}

}
