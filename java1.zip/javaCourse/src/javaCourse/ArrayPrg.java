package javaCourse;
import java.util.Scanner;
public class ArrayPrg {
    public static void main(String[] args) {
        
        Scanner obj = new Scanner(System.in);
        int n = obj.nextInt();
        System.out.println("The Input Provided is: " + n);
        int check=obj.nextInt();
        System.out.println("Number to check:"+ check);
        
        int[] a=new int[n];
        for(int i=0;i<n;i++){
           a[i]=obj.nextInt();
        }
        //System.out.println(values);
        
        boolean exist= false;
        for(int j=0;j<n;j++){
            //int values;
        if(a[j]==check){
            exist=true;
            break;}}
        if(exist)
         System.out.println("YES");
        
        else
         System.out.println("NO");
    }
}