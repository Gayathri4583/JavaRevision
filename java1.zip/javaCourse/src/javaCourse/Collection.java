package javaCourse;

import java.util.*;

public class Collection {

	public static void main(String[] args) {
		//array
		int c[]=new int[3];
		//arraylist
		ArrayList<Integer> alist=new ArrayList<Integer>();
		
		for (int i=1;i<=20;i++) {
			alist.add(i);
		}
			alist.add(100);
		System.out.println(alist);
		System.out.println(alist.get(12));
		System.out.println(alist.contains(20));
		alist.set(0, 200);
		System.out.println(alist);
		alist.remove(0);
		for(int i:alist)//normal format to print order by order
			System.out.println(i);
		Iterator<Integer> i=alist.iterator();
		System.out.println(i.hasNext());
		while(i.hasNext()) {//using loop
			System.out.println(i.next());
		}
		ArrayList<String> slist=new ArrayList<String>();
		slist.add("Helo");
		System.out.println(slist);	
		//Queue
		Queue<String> q=new LinkedList<String>(); 
		q.add("Hey!");
		System.out.println(q);
		PriorityQueue<Integer> p=new PriorityQueue<Integer>();
		p.add(2);
		p.add(3);
		p.add(5);
		p.add(8);
		System.out.println(p);
		System.out.println(p.peek());
		System.out.println(p.poll());//print null if the list is empty
		System.out.println(p.remove(8));//shows an error if the list is empty
		
		//set -- no repetition nd no duplicate
		//hashset key%n it can any rule
		HashSet<Integer> h=new HashSet<Integer>();// print in any order LinkedHashSet will print in order TreeSet will add in alphabetic ordere
		h.add(2);
		h.add(3);
		h.add(92);
		h.add(2);
		System.out.println(h);
	}
}
