package javaCourse;

public class LeapYear {

	public static void main(String[] args) {
		int year=1900;
		if((year%4==0 && year%100 !=0)|| year%400==0) {
			System.out.println(year+" is leap year");
		}
		else {
			System.out.println(year+" is not leap year");
		}
		//LeapYear l=new LeapYear();
		//int a=10,b=19;
		int r= gcd(10,100);
		System.out.println("GCD:"+r);
		int r1=lcm(10,100);
		System.out.println("LCM:"+r1);
	}
	public static int gcd(int x,int y) {
		while(y!=0) {
			int temp=y;
			y=x%y;
			x=temp;
		}
		return x;
		
	}
	public static int lcm(int x,int y) {
		return x*y/gcd(x,y);
		
	}

}
