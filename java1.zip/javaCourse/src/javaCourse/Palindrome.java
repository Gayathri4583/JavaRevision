package javaCourse;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter word:");
		String s=sc.next();
		String r="";
		System.out.println("word:"+s);
		char ch;
		for(int x=0;x<s.length();x++) {
			ch=s.charAt(x);
			r=ch+r;
		}
		System.out.println("reverse:"+r);
		if(r==s) {
			System.out.println("Palindrome");
		}
		else{
			System.out.println("Not a Palindrome");
		}
	}
}
