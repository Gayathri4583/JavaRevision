package javaCourse;

import java.util.Scanner;

public class TempConversion {

	public static void main(String[] args) {
	float celsius=10,faren=234;
	double kelvin=12.4;
	char ch;
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the conversion: 1.Celsius to Farenheit  2.celsius to Kelvin  3.kelvin to Farenheit");
	ch=s.next().charAt(0);
	//System.out.println("Enter Celsius:");
	switch(ch) {
	case '1':
		faren=(celsius*9/5)+32;
		System.out.print("Celsius to Farenheit:"+faren);
	case '2':
		celsius=(faren-32)*9/5;
		System.out.print("Celsius to kelvin :"+celsius);
	case '3':
		//kelvin=celsius+273.15;
		kelvin=(faren-32)*9/5+273.15;
		System.out.print("Kelvin to Farenheit:"+kelvin);
	}
	}

}
