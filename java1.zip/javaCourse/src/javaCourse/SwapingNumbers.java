package javaCourse;

import java.util.Scanner;

public class SwapingNumbers {

	public static void main(String[] args) {
		//int a=105,b=200,temp;
		Scanner obj1=new Scanner(System.in);
		System.out.println("firstnum:");
		int firstnum=obj1.nextInt();
		System.out.println("secondnum:");
		int secondnum=obj1.nextInt();
		
		/*temp=a;
		a=b;
		b=temp;
		a=a+b;
		b=a-b;
		a=a-b;*/
		firstnum=firstnum*secondnum;
		secondnum=firstnum/secondnum;
		firstnum=firstnum/secondnum;
		System.out.println(firstnum);
		System.out.println(secondnum);
	}

}
