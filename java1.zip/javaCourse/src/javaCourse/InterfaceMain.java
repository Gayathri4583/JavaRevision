package javaCourse;

interface InterfaceMain {
	abstract void sales1();
	abstract void sales2();
}
interface InterfaceBranch{
	abstract void sales1();
	abstract void sales2();
}
class Shop implements InterfaceMain,InterfaceBranch{
	public void sales1() {
		System.out.println("Good Sales in sales1");
	}
	public void sales2() {
		System.out.println("Better Sales in sales2");
	}
	public static void main(String args[]) {
		Shop s=new Shop();
		s.sales1();
		s.sales2();
	}
}