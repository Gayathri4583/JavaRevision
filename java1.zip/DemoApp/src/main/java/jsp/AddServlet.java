package jsp;
import java.lang.Integer;
import java.lang.String;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddServlet extends HttpServlet{

	public void service(HttpServletRequest r,HttpServletResponse rep) {
		int a=Integer.parseInt(r.getParameter("n1"));
		int b=Integer.parseInt(r.getParameter("n2"));
		int result=a+b;
		System.out.println(result);
	}

}
